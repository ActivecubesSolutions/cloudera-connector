/**
* StringConverter.java
* Created on 10/08/2013 by Nikolay Chorniy
*/
class StringConverter extends ValueConverter<String> {
    @Override
    public String convert(String value) {
        return value;
    }
}
