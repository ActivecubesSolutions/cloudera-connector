# Project Hadoop JDBC

This project is designed to extract relational data from an HDFS (Hadoop distributed file system). There are some possibilities to extract data from hadoop indeed, but they don't offer a good solution using your existing data analyze software. Also, to perform a quick check of the last map reduce results, you will need an interface, which allows you to keep track of you data in time, using add hoc queries. 

## Important 

This tool treats a set of files from a HDFS as a relational table, similar to tables in a database management system like MySQL of DB2. 

This is a driver-like tool based on the JDBC interface. You can use it out of source or in an arbitrary jdbc tool.
 
In the moment, there are only read operations supported. Remember that the driver will extract your data sequentialy, 
so you should not query big data sets without giving the JVM enough heap space (use the parameters e.g. "-Xms100m -XmX1024" while starting the JVM). 
This driver is builed for showing results, e.g. produced by map reduce jobs.
You can only use the projection and selection functions of relation algebra.

If you need other functionality, e.g. a file based data extraction or a distributed key-value store instead, check out the following hadoop tools:
- HIVE (a data warehouse, like a RDBMS)
- HBase (a NoSQL database)
- Command line interface (CRUD)
- Hadoop JAVA API (CRUD)
- RESTful hadoop webservice (CRUD)
- Flume (Service for file exchange) 
- Scoop (service for data exchange, e.g. insert data to an hbase instance)
- HDFS slurper (easy file exchange tool)

Note that the csv-jdbc driver library, which is used to create JDBC result sets, was edited by us for providing the ability to handle files with different column size.
This change was made to improve the robustness of the driver.
All changes of this library are licensed under the LGPL. If you are interested, you can retrieve the code for this library from us. 
A license file for our version of the csv-jdbc is arranged too.

## Usage

### Include the driver 

You can include the driver like an usual jdbc driver. Make sure, that the library (jar-)files are in a directory called "lib" next to the connectors jar file.

You must have the appropriate driver for your hadoop version. There are driver versions for the hadoop 1.0.3 (current stable release, e.g. Cloudera Version 3) and the version 2.0.1 (current alpha release, e.g. Cloudera Version 4).

### Specify the driver class

The JDBC mechanism uses the class name of a driver to reflect and load it during runtime. Thus, you need to tell your application the driver name, which is given as:

de.tiq.hadoop.TIQHdfsDriver

### Connect to your HDFS

For being able to connect, specify the following jdbc URL:

`jdbc:hdfs//<theHDFShost>:<PORT>?PARAMS=VALUE`

Currently, there are no security protocols implemented.

#### Settings for your connection

There are parameters (key-value pairs), which are appended to the URL like ordinary HTTP GET parameters after the question mark token:

-- user=<YourHDFSUserName> - connects you to the HDFS with the specified user name, e.g. `...?user=root`
-- recursive=<boolean> - if true, the driver will match files in any subdirectory when querying the HDFS with a regular expression. Use: `...?recursive=true` The default is false.
-- separator=<MaskedSeparatorSign> - set the column separator of your data, the default is a TAB '\t' `...?separator=,` you may also use a URL mask for special characters: `...?separator=%44`
-- skip_header=<boolean> - if true, it will skip the header lines when concatenating a set of files, e.g. `...?skip_header=true` The default is false.

Dependending on the usage of the driver, you will probably have to add the following parameter for suppressing the occurrence of an UnsupportedOperationException: 
-- raiseUnsupportedOperationException=<boolean>

Note that you must concatenate the parameters with an '&'-token in the way of an usual URL, like:

?user=hduser&separator=%44&skip_header=true

**The whole URL might look like:**

`jdbc:hdfs://localhost:9000?user=hduser&recursive=true&separator=%44&skip_header=true&raiseUnsupportedOperationException=false`

#### Default values

Of course, it is not necessary to use all these parameters. You can stick with the default values:

`jdbc:hdfs://localhost:9000`

or if you use a application frontend:

`jdbc:hdfs://localhost:9000?UnsupportedOperationException=false`

It will connect you to the HDFS with the following parameters:
user = currentSystemUser
recursive = false
separator = '\t' (%09)
skip_header = false

### Create Statements
The main functionality of the driver consists of issuing SQL queries. It will get the data from a file out of the HDFS.
I remind you again that the data should be organized in a relational way, e.g. .csv files. The speparator of the columns can be set in form of a parameter (check the part "settings for your connection" again if you not already have).

#### Single file:
For retrieving data from a file of the HDFS, you can set the path to the file in the from clause of the select statement. 
For a single file the syntax appears to be like this:

`select * | CommaSeperatedColumnList From /path/to/hdfs/object`

seeing that the from clause represents a path in the hdfs like `/input/data.csv`.

For a single file, it is allowed to omit the .csv suffix.

#### Set of files:
When concatenating files, please keep in mind that the first file determines the structure of the whole table. 
All other files will be interpreted as they would have the same column structure. 
Knowing that, missing columns will be treated as NULL values and additional columns will be lost. 
We assume that you don't want to mix up unrelated data with each other.
If you need join functionality, checkout a map reduce job in hadoop to transform the data in the appropriate structure.

You can state a set of files as a comma separated list, e.g. 

`select * from /path/file1,/path/file2,/file3`

they don't need to be in the same directory. Between the different files there must not be a whitespace.

The first given path in such an expression is called "base path". We estimate that you want to extract more files you of the base path. 
You can use the following query:

`select * from /path/file1,file2,file3`

which will return the data of file1, file2 and file3 out of the /path directory from your HDFS. 

#### Regular expression:
You can use a (java) regular expression to retrieve a set of files, which are matched by a given pattern. 
They should contain the same column structure again, because the first file still determines the header.
A pattern is initiated by a hash character (#). For example:

`select * from /path/#csv$`

would extract all files, which end with the character suffix csv. It will search recursively, if you specify the `recursive=true` parameter in the URL.

#### Directories:

For providing an easy way to navigate, you can also pose a query to retrieve directory informations. Try:

`select * from /` 

and you see a basic Unix like index of the root directory from your HDFS.

#### Demo mode

The demo version of this software is limited to fetch 1000 rows of data. 
As a demo, this program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

If you have any questions, feel free to ask us:

ralf.becher@tiq-solutions.de





