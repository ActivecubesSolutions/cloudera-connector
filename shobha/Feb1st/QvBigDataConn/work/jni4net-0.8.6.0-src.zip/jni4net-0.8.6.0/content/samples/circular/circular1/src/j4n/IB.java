package j4n;
public interface IB
{
  void m2(IA a);
}